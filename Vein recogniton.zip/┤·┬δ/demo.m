 
 
clc;clear;close all
img=imread('1_1.bmp');
 
 
gray = double(img)/255;
 
himg = homomorphic(gray, 2, 0.2, 0.1,[0.1,55]);
%convert back to 0-255 uint8
himg = uint8(min(himg*255,255));

%display results
figure()
imshow(gray)
title('Original Image')
figure()
imshow(himg);
title('After Homomorphic Normalization')
