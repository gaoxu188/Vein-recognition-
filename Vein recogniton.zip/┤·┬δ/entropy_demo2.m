
clear  ;
close all;
image1 = imread('a.bmp');


[C1 R1]=size(image1); 
image1_size=C1*R1; 
H1=0;
n=zeros(256,1);
for i=1:C1
for j=1:R1
img_level=image1(i,j)+1;  
n(img_level)=n(img_level)+1;  
end
end
for k=1:256 
p(k)=n(k)/image1_size ;
if p(k)~=0;  
H1=-p(k).*log2(p(k))+H1;  
end
end
H1 
 