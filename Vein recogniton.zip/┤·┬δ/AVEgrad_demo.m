
 
clear;
close all;
img = imread('a.bmp');  
N = 64;  
block_size = 8;  
stride = 4;  
 
blk_count = 0;
ssim_sum = 0;
G_blk = zeros(block_size,block_size,1);
Gr_blk = zeros(block_size,block_size,1);
G_std = zeros(1);
 
%% (1)Ir
sigma = sqrt(6);
if size(img,3) == 3
    img = rgb2gray(img);  
end
[m,n] = size(img);
gausFilter = fspecial('gaussian',[7 7],sigma); 
Ir = imfilter(img,gausFilter,'replicate');
figure,
subplot(121),imshow(img,[]),title('Original Image');
subplot(122),imshow(Ir,[]),title('Gaussian Filter Image');
 
G = edge(img,'sobel');  
Gr= edge(Ir,'sobel');
figure,
subplot(121),imshow(G),title('G');
subplot(122),imshow(Gr),title('Gr');
 