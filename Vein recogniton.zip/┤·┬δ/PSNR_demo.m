
clc;
close all;
X = imread('5.bmp');%           
Y = imread('1.bmp');
figure;%                          
subplot(1, 3, 1); imshow(X); title('q1');
subplot(1, 3, 2); imshow(Y); title('q2');
%                                 
X = double(X);
Y = double(Y);
 
A = Y-X;
B = X.*Y;
RMSE = sum(A(:).*A(:))/numel(Y)%  
PSNR = 10*log10(255^2/RMSE)%      

display(PSNR);%PSNR
 