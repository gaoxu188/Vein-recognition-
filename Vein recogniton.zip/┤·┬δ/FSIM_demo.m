clc

clear all

close all;

A  = imread('a.bmp');  
a   = imread('b.bmp');  

 
%     A = imresize(A,[256,256]);
[FSIM, FSIMc] = FeatureSIM(a, A);%
S=  FSIM %